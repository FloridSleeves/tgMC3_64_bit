char version[]="$Id: mb.c,v 1.1 2005/03/21 19:02:22 paulvdm Exp $";

