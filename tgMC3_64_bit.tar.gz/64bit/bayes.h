int  DoQuit (void);
void GetTimeSeed (void);
void InitializeMrBayes (void);
void MrBayesPrint (char *, ...);
void MrBayesPrintf (FILE *f, char *format, ...);
int  ReinitializeMrBayes (void);
void SetCode (int part);
void SetModelDefaults (void);

extern int InitializeLinks (void);

